# Crop Insurance Backend (Django + DRF)

This is a ready-to-run backend for the Crop Insurance Verification System.
It provides:
- JWT authentication (Simple JWT)
- User registration with role (farmer/admin)
- Claim model: farmers submit claims; admins approve/reject
- Policy model: read by farmers, admin can create/edit
- CORS enabled for frontend

## Quick start (local development)

1. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate   # Linux/macOS
   venv\Scripts\activate    # Windows
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set environment variables (optional):
   - `DJANGO_DEBUG=1` (default)
   - `DJANGO_SECRET_KEY` a secret in production
   - or configure `POSTGRES_DB`, `POSTGRES_USER`, etc. for PostgreSQL

4. Run migrations and create superuser:
   ```
   python manage.py makemigrations
   python manage.py migrate
   python manage.py createsuperuser
   ```

5. Run server:
   ```
   python manage.py runserver
   ```

## API endpoints
- `POST /api/token/` → Obtain JWT `access` and `refresh`
- `POST /api/token/refresh/` → Refresh token
- `POST /api/users/` → Register user (include `role` in payload to create admin: {"username":..., "password":..., "role":"admin"})
- `/api/claims/` → CRUD claims (farmers: own claims; admins: all)
- `/api/claims/<id>/change_status/` → PATCH to change status (admin only)
- `/api/policies/` → list/create policies (readable by all; create by admin)

## Notes
- This scaffold is designed to integrate with Pratik's React frontend.
- Adjust CORS settings and DEBUG for production.
