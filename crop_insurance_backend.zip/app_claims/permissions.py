from rest_framework import permissions

class IsAdminOrOwner(permissions.BasePermission):
    '''
    - Admin users (UserProfile.role == 'admin') can do anything.
    - Owners can create/read their own claims and update/delete their own claims (not approve).
    - Approve/Reject actions should be restricted to admins at the view level.
    '''

    def has_permission(self, request, view):
        # Allow authenticated users to list/create.
        return request.user and request.user.is_authenticated

    def has_object_permission(self, request, view, obj):
        # Admins can do anything
        profile = getattr(request.user, 'profile', None)
        if profile and profile.role == 'admin':
            return True
        # Owners can access their own objects
        return obj.user == request.user
