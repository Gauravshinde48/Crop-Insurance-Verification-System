from rest_framework import serializers
from .models import Claim
from django.contrib.auth.models import User
from app_users.serializers import UserDetailSerializer

class ClaimSerializer(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)

    class Meta:
        model = Claim
        fields = ['id', 'user', 'title', 'description', 'status', 'created_at', 'updated_at']
        read_only_fields = ['status', 'created_at', 'updated_at', 'user']
