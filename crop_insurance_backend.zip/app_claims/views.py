from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Claim
from .serializers import ClaimSerializer
from .permissions import IsAdminOrOwner

class ClaimViewSet(viewsets.ModelViewSet):
    queryset = Claim.objects.all().order_by('-created_at')
    serializer_class = ClaimSerializer
    permission_classes = [IsAdminOrOwner]

    def perform_create(self, serializer):
        # set the user as the requester
        serializer.save(user=self.request.user)

    def get_queryset(self):
        # farmers see only their claims; admins see all
        profile = getattr(self.request.user, 'profile', None)
        if profile and profile.role == 'admin':
            return Claim.objects.all().order_by('-created_at')
        return Claim.objects.filter(user=self.request.user).order_by('-created_at')

    @action(detail=True, methods=['patch'], permission_classes=[permissions.IsAuthenticated])
    def change_status(self, request, pk=None):
        ''' Admin-only: change status to Approved/Rejected '''
        profile = getattr(request.user, 'profile', None)
        if not (profile and profile.role == 'admin'):
            return Response({'detail': 'Only admin can change status.'}, status=status.HTTP_403_FORBIDDEN)
        claim = self.get_object()
        status_value = request.data.get('status')
        if status_value not in ['Pending', 'Approved', 'Rejected']:
            return Response({'detail': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)
        claim.status = status_value
        claim.save()
        return Response(self.get_serializer(claim).data)
