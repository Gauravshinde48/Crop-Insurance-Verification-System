from rest_framework import viewsets, permissions
from .models import Policy
from .serializers import PolicySerializer
from app_users.models import UserProfile

class IsAdminOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        profile = getattr(request.user, 'profile', None)
        return profile and profile.role == 'admin'

class PolicyViewSet(viewsets.ModelViewSet):
    queryset = Policy.objects.all().order_by('-created_at')
    serializer_class = PolicySerializer
    permission_classes = [IsAdminOrReadOnly]
