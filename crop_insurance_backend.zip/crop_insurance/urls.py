from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from app_users.views import UserViewSet
from app_claims.views import ClaimViewSet
from app_policies.views import PolicyViewSet
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

router = routers.DefaultRouter()
router.register(r'users', UserViewSet, basename='user')
router.register(r'claims', ClaimViewSet, basename='claim')
router.register(r'policies', PolicyViewSet, basename='policy')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
